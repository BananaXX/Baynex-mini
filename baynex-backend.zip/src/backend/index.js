
const WebSocket = require('ws');
const axios = require('axios');
require('dotenv').config();

const DERIV_APP_ID = process.env.DERIV_APP_ID;
const DERIV_API_TOKEN = process.env.DERIV_API_TOKEN;
const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const TELEGRAM_CHAT_ID = process.env.TELEGRAM_CHAT_ID;

const ws = new WebSocket('wss://ws.derivws.com/websockets/v3?app_id=' + DERIV_APP_ID);

function sendTelegramMessage(message) {
    const url = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`;
    axios.post(url, {
        chat_id: TELEGRAM_CHAT_ID,
        text: message,
    }).catch(err => console.error('Telegram Error:', err.message));
}

ws.onopen = () => {
    sendTelegramMessage('✅ BAYNEX Bot Connected to Deriv');
    ws.send(JSON.stringify({ authorize: DERIV_API_TOKEN }));
};

ws.onmessage = (msg) => {
    const data = JSON.parse(msg.data);
    if (data.msg_type === 'authorize') {
        sendTelegramMessage('✅ Authorized on Deriv');
        const proposal = {
            buy: 1,
            price: 0.35,
            parameters: {
                amount: 0.35,
                basis: 'stake',
                contract_type: 'CALL',
                currency: 'USD',
                duration: 1,
                duration_unit: 'm',
                symbol: 'R_100'
            }
        };
        ws.send(JSON.stringify(proposal));
    }
    if (data.msg_type === 'buy') {
        sendTelegramMessage(`✅ Buy Confirmed: ${data.buy.contract_id}`);
    }
};

ws.onclose = () => {
    sendTelegramMessage('❌ Disconnected from Deriv');
};

ws.onerror = (err) => {
    console.error('WebSocket Error:', err);
};
